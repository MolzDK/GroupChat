const express = require('express')
const router = express.Router()
const users = require('./modules/user')

router.get('/', (req, res) => {
    users('Chrille', 'Christian', 'Møller', 'chrilletmoller@gmail.com', 'oppwd', 'oppwd', 'abcdef', 'man')
    res.render('index', {})
})

router.get('/next', (req, res) => {
    res.render('next', {})
})

router.get('/last', (req, res) => {
    res.render('last', {})
})

module.exports = router