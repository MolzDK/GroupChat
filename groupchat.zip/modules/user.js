module.exports = (uname, fname, lname, email, paswd, cpaswd, classroomid, gender) => {
    console.log(uname, fname, lname, email, paswd, cpaswd, classroomid, gender)
}