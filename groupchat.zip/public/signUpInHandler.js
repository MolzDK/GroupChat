const upForm = document.getElementById('sign-up-form')

const socket = io('ws://localhost:80')

socket.on('connect', () => {
    console.log('Connected from ' + socket.id + '!')
    document.getElementById('id').innerText = 'Socket ID: ' + socket.id + ''
})

upForm.onsubmit = (e) => {
    e.preventDefault()
    
}