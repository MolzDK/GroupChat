const express = require('express')
const app = express()
const path = require('path')

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))
app.use(express.static(path.join(__dirname, 'public')))
app.use(require('./routes'))

const server = app.listen('80', (err) => {
    if (err) throw err
    console.log('listening on http://localhost:80')
})
const io = require('socket.io')(server)